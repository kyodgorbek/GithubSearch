I've used following Technologies:

- MVVM
- Kotlin Coroutines
- Kotlin Coroutines Flow  
- Kotlin
- Retrofit
- Glide
- Unit and Automated Testing
- Paging

